<?php

require_once 'db_connect.php';

require_once '../navbar2.php';

if($_POST) {
    $eventName = $_POST['eventName'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];
    $description = $_POST['description'];
    $img = $_POST['img'];
    $capacity = $_POST['capacity'];
    $contactEmail = $_POST['contactEmail'];
    $contactPhone = $_POST['contactPhone'];
    $evLoc = $_POST['evLoc'];
    $eventLocStreet = $_POST['evStreet'];
    $eventLocCity = $_POST['evCity'];
    $url = $_POST['url'];
    $fk_eventType = $_POST['fk_eventType'];


    $sql = "UPDATE events 
    SET eventName= '$eventName', 
    startDate = '$startDate', 
    endDate = '$endDate', 
    description = '$description', 
    img = '$img', 
    capacity = '$capacity', 
    contactEmail = '$contactEmail', 
    contactPhone = '$contactPhone', 
    evLoc = '$elvLoc', 
    evStreet = '$evStreet', 
    evCity = '$evCity', 
    url = 'eurl', 
    fk_eventType = '$fk_eventType',
    WHERE id = {$id}";

    if($conn->query($sql) === TRUE) {
        echo "<p>Succcessfully Updated</p>";
        echo "<a href='../update.php?id=".$eid."'><button type='button' class='btn btn-info'>Back</button></a>";
        echo "<a href='../home.php'><button type='button' class='btn btn-secondary'>Home</button></a>";
    } else {
        echo "Erorr while updating record : ". $conn->error;
    }

    $conn->close();
}

?>
</body>
</html>