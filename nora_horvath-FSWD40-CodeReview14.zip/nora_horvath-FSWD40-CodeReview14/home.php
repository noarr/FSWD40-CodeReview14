<?php
 ob_start();
 session_start();

 require_once 'actions/db_connect.php';


 if( !isset($_SESSION['user']) ) {
  header("Location: login.php");
  exit;
 }

$res=mysqli_query($conn, "SELECT * FROM users WHERE userId=".$_SESSION['user']);
$userRow=mysqli_fetch_array($res, MYSQLI_ASSOC);

require_once 'navbar2.php';
?>

<div class="container-fluid bg-3 text-center">    
  <h1>Admin of all events</h1><a href='create.php'><button type='button' class='btn btn-primary'>Create Event</button></a>
  <br><br>
  <div class="row">
    <?php
    $sql = "SELECT * FROM `events`";
    $result = $conn->query($sql);
    if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "
        <div class='col-sm-2'>
        <img src='img/".$row['img']."' class='img-responsive' style='width:100%' alt='Image'>
        <p></p>
     <h4>".$row['eventName']."</h4><br><p>".$row['startDate']."<br> until <br>".$row['endDate']."<br>".$row['evLoc']." </p>

     <form action='actions/a_update.php' method='get'>
     <a href='update.php?id=".$row['id']."'><button type='button' class='btn btn-success'>Edit Event</button></a>
     </form>

     <form action='actions/a_delete.php' method='get'>
     <a href='delete.php?id=".$row['id']."'><button type='button' class='btn btn-danger'>Delete Event</button></a>
     </form>

     </div><br><br>
     ";
    }
    } else {
    echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
}
?>     
    
  </div>
</div><br><br>  

    <footer class="container-fluid text-center footer">
      <p>noar &#169; 2018</p>
    </footer>
</body>
</html>
<?php ob_end_flush(); ?>