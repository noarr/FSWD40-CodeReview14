-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2018 at 04:50 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr14_nora_horvath_bigevents`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `img` varchar(20) NOT NULL,
  `contactEmail` varchar(55) DEFAULT NULL,
  `contactPhone` varchar(55) DEFAULT NULL,
  `evLoc` varchar(55) DEFAULT NULL,
  `evStreet` varchar(90) DEFAULT NULL,
  `evCity` varchar(55) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `FK_eventtype` int(11) DEFAULT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `eventName`, `description`, `capacity`, `img`, `contactEmail`, `contactPhone`, `evLoc`, `evStreet`, `evCity`, `url`, `FK_eventtype`, `startDate`, `endDate`) VALUES
(1, 'Water Sound', 'Transit, the latest outpouring from German Director Petzold, tells the story of a man desperate to escape Paris with the Germans knocking on the Gates.', 200, '1.jpg', 'sdf@ag.com', '+3645125798', 'The Red House', 'Red street 23.', 'Vienna', 'www.google.com', 1, '2018-07-08 04:00:00', '2018-07-02 09:00:00'),
(2, 'Never the less', 'Transit, the latest outpouring from German Director Petzold, tells the story of a man desperate to escape Paris with the Germans knocking on the Gates.', 200, '2.jpg', 'asdf@ewr.com', '+6597984621', 'Santas bar', '23. Leopoldgasse', 'Vienna 1201', 'http:www.asldkfjg.com', 3, '2018-07-15 19:00:00', '2018-07-15 22:00:00'),
(3, 'Transit for us', 'Transit, the latest outpouring from German Director Petzold, tells the story of a man desperate to escape Paris with the Germans knocking on the Gates.', 3000, '3.jpg', 'aed@wer.com', '+56457894556', 'Big HUb', '12. Ertergasse', '1230 Vienna', 'http://erter.com', 2, '2018-07-15 14:00:00', '2018-07-15 23:00:00'),
(4, 'Summerfest', 'Transit, the latest outpouring from German Director Petzold, tells the story of a man desperate to escape Paris with the Germans knocking on the Gates.', 21000, '4.jpg', 'asdf@asdf.com', '+45789845614', 'The Big festival ', '1. Regargasse', 'Vienna 1234', 'http://reda.com', 4, '2018-07-22 19:00:00', '2018-07-23 09:00:00'),
(5, 'ErderFest', 'Transit, the latest outpouring from German Director Petzold, tells the story of a man desperate to escape Paris with the Germans knocking on the Gates.', 500, '6.jpg', 'eerte@gfds.com', '+457897432', 'ErderHause', '34. erdergasse', 'Vienna 1231', 'http://erder.com', 1, '2018-07-19 17:00:00', '2018-07-20 02:00:00'),
(7, 'WehereeverFest', 'Assuming a dead man’s identity in the hopes of escaping to Mexico via Marseille, however was not as quick as he hoped, leaving him semi-stranded, but not alone, as he encounters an equally on-the-road-to-nowhere lady.', 15000, '7.jpg', 'sdga@dg.com', '+7845613213', 'DonauInsel', '1. Donaugasse', 'Vienna 1230', 'htpp://dounau.com', 1, '2018-07-01 05:00:00', '2018-07-06 19:00:00'),
(8, 'Localhuss', 'Assuming a dead man’s identity in the hopes of escaping to Mexico via Marseille, however was not as quick as he hoped, leaving him semi-stranded, but not alone, as he encounters an equally on-the-road-to-nowhere lady.', 200, '11.jpg', 'contact@email.com', '+123456879', 'BihBar', '12. Biharigasse', 'Vienna 1231', 'http://bih.com', 1, '2018-07-16 18:00:00', '2018-07-18 21:00:00'),
(12, 'JazzNights', 'Viennas home for SMOOTH SUNDAYS by SmoothJazz.com Global with the stars of Smooth Jazz : Nathan East, Brian Simpson, Jonathan Fritzen, Paul Brown.', 150, '9.jpg', 'jazz@gmail.com', '1234552335', 'JazzHouse', '12. Miles Davis Gasse', '1212 Vienna', 'http://jazzvienna.com', 1, '2018-07-17 19:00:00', '2018-07-17 23:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `eventtype`
--

CREATE TABLE `eventtype` (
  `eventTypeId` int(11) NOT NULL,
  `eventType` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eventtype`
--

INSERT INTO `eventtype` (`eventTypeId`, `eventType`) VALUES
(3, 'movie'),
(1, 'music'),
(2, 'sport'),
(4, 'theater');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `userPass` varchar(255) DEFAULT NULL,
  `Surname` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userEmail`, `userPass`, `Surname`, `userName`) VALUES
(0, 'asdf@gasd.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'asdf', 'sadf'),
(1, 'blame@gmail.com', '123456', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_eventtype` (`FK_eventtype`);

--
-- Indexes for table `eventtype`
--
ALTER TABLE `eventtype`
  ADD PRIMARY KEY (`eventTypeId`),
  ADD KEY `eventType` (`eventType`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`FK_eventtype`) REFERENCES `eventtype` (`eventTypeId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
