<?php 
mysqli_free_result($result);

mysqli_close($conn); 
?>
<?php ob_end_flush(); ?>
          

</body>
</html>
